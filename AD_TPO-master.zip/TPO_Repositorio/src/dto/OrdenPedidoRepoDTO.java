// PENDIENTE
package dto;

import java.io.Serializable;

public class OrdenPedidoRepoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public OrdenPedidoRepoDTO() {
		// TODO Auto-generated constructor stub
	}

}
