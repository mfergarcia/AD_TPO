package test;


import java.rmi.RemoteException;

import servidor.Servidor;

public class TestServidor_FER {

	public TestServidor_FER() {
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String[] args) throws RemoteException {
		// TODO Auto-generated method stub
		new Servidor();
	}

}
