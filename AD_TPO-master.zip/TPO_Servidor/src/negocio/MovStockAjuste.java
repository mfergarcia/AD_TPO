//PENDIENTE: Programar todo
package negocio;

public class MovStockAjuste extends MovimientoStock {

	public ArticuloEnStock artEnStock;	
	
	public MovStockAjuste() {
		// TODO Auto-generated constructor stub
	}

	// NOTAS_FG: Ver si se puede reemplazar usando el constructor
	public void registrarMovStockAjuste(int cant) {
		
	}

	// NOTAS_FG: Para qu� sirve este metodo? Qu� calcula?	
	public void calcularMoviento() {
		
	}
	
	public ArticuloEnStock getArtEnStock() {
		return artEnStock;
	}

	public void setArtEnStock(ArticuloEnStock artEnStock) {
		this.artEnStock = artEnStock;
	}

}
